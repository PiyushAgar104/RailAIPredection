import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

export const Train3DCanvas: React.FC = () => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [speedDisplay, setSpeedDisplay] = useState(160);
  const [telemetryState, setTelemetryState] = useState('NOMINAL');

  useEffect(() => {
    const currentMount = mountRef.current;
    if (!currentMount) return;

    const width = currentMount.clientWidth;
    const height = currentMount.clientHeight;

    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x030712, 0.025);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 2.5, 12);
    camera.lookAt(0, 1, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    currentMount.appendChild(renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0x0f172a, 1.5);
    scene.add(ambientLight);

    const blueDirLight = new THREE.DirectionalLight(0x00f2fe, 3);
    blueDirLight.position.set(5, 10, 5);
    scene.add(blueDirLight);

    const purplePointLight = new THREE.PointLight(0x7f00ff, 4, 30);
    purplePointLight.position.set(-4, 3, -2);
    scene.add(purplePointLight);

    // Train Group
    const trainGroup = new THREE.Group();

    // Body
    const bodyGeometry = new THREE.BoxGeometry(2.2, 1.8, 6.5);
    const bodyMaterial = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      metalness: 0.9,
      roughness: 0.2,
    });
    const trainBody = new THREE.Mesh(bodyGeometry, bodyMaterial);
    trainBody.position.y = 1.3;
    trainGroup.add(trainBody);

    // Aerodynamic Nose
    const noseGeometry = new THREE.CylinderGeometry(0.2, 1.2, 2.5, 4);
    const noseMaterial = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      metalness: 0.8,
      roughness: 0.1,
    });
    const trainNose = new THREE.Mesh(noseGeometry, noseMaterial);
    trainNose.rotation.x = Math.PI / 2.3;
    trainNose.rotation.y = Math.PI / 4;
    trainNose.position.set(0, 1.2, 4);
    trainGroup.add(trainNose);

    // Blue Neon Stripe
    const stripeMat = new THREE.MeshBasicMaterial({ color: 0x00f2fe });
    const stripeGeo = new THREE.BoxGeometry(2.3, 0.15, 6.4);
    const stripe = new THREE.Mesh(stripeGeo, stripeMat);
    stripe.position.set(0, 1.4, 0);
    trainGroup.add(stripe);

    // Dual High-Beam LED Headlights
    const headlightMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const headlightGeo = new THREE.SphereGeometry(0.2, 16, 16);

    const leftLight = new THREE.Mesh(headlightGeo, headlightMat);
    leftLight.position.set(-0.7, 1.1, 4.6);
    trainGroup.add(leftLight);

    const rightLight = new THREE.Mesh(headlightGeo, headlightMat);
    rightLight.position.set(0.7, 1.1, 4.6);
    trainGroup.add(rightLight);

    // Light Beams
    const spotLight1 = new THREE.SpotLight(0x00f2fe, 10, 25, Math.PI / 8, 0.5);
    spotLight1.position.set(-0.7, 1.1, 4.6);
    spotLight1.target.position.set(-0.7, 0, 20);
    trainGroup.add(spotLight1);
    trainGroup.add(spotLight1.target);

    const spotLight2 = new THREE.SpotLight(0x00f2fe, 10, 25, Math.PI / 8, 0.5);
    spotLight2.position.set(0.7, 1.1, 4.6);
    spotLight2.target.position.set(0.7, 0, 20);
    trainGroup.add(spotLight2);
    trainGroup.add(spotLight2.target);

    // Pantograph
    const pantoMat = new THREE.MeshBasicMaterial({ color: 0x00f2fe });
    const pantoGeo = new THREE.CylinderGeometry(0.04, 0.04, 1.2);
    const pantoLeft = new THREE.Mesh(pantoGeo, pantoMat);
    pantoLeft.position.set(-0.4, 2.5, -1);
    pantoLeft.rotation.z = Math.PI / 6;
    trainGroup.add(pantoLeft);

    const pantoRight = new THREE.Mesh(pantoGeo, pantoMat);
    pantoRight.position.set(0.4, 2.5, -1);
    pantoRight.rotation.z = -Math.PI / 6;
    trainGroup.add(pantoRight);

    scene.add(trainGroup);

    // Digital Railway Tracks
    const trackGroup = new THREE.Group();
    const railMat = new THREE.MeshStandardMaterial({
      color: 0x00f2fe,
      roughness: 0.1,
      metalness: 0.9,
      emissive: 0x004488
    });

    const railGeo = new THREE.BoxGeometry(0.12, 0.15, 100);
    const leftRail = new THREE.Mesh(railGeo, railMat);
    leftRail.position.set(-1.1, 0.1, 0);
    trackGroup.add(leftRail);

    const rightRail = new THREE.Mesh(railGeo, railMat);
    rightRail.position.set(1.1, 0.1, 0);
    trackGroup.add(rightRail);

    // Sleeper Ties
    const tieGeo = new THREE.BoxGeometry(2.6, 0.08, 0.3);
    const tieMat = new THREE.MeshBasicMaterial({ color: 0x1e293b });

    for (let z = -50; z < 50; z += 1.5) {
      const tie = new THREE.Mesh(tieGeo, tieMat);
      tie.position.set(0, 0.04, z);
      trackGroup.add(tie);
    }
    scene.add(trackGroup);

    // Speed Particles
    const particleCount = 400;
    const particleGeo = new THREE.BufferGeometry();
    const particlePos = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
      particlePos[i] = (Math.random() - 0.5) * 30;
      particlePos[i + 1] = Math.random() * 10;
      particlePos[i + 2] = (Math.random() - 0.5) * 60;
    }

    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePos, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0x00f2fe,
      size: 0.08,
      transparent: true,
      opacity: 0.7
    });

    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    // Animation Loop using performance.now() to avoid THREE.Clock deprecation warning
    let startTime = performance.now();
    let animationFrameId: number;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsedTime = (performance.now() - startTime) / 1000;

      trainGroup.position.y = Math.sin(elapsedTime * 3) * 0.05;
      trainGroup.position.z = Math.sin(elapsedTime * 0.8) * 0.4;
      trackGroup.position.z = (elapsedTime * 18) % 1.5;

      const positions = particleGeo.attributes.position.array as Float32Array;
      for (let i = 2; i < particleCount * 3; i += 3) {
        positions[i] += 0.4;
        if (positions[i] > 25) {
          positions[i] = -35;
        }
      }
      particleGeo.attributes.position.needsUpdate = true;

      camera.position.x = Math.sin(elapsedTime * 0.5) * 0.5;

      renderer.render(scene, camera);
    };

    animate();

    const speedInterval = setInterval(() => {
      setSpeedDisplay(155 + Math.floor(Math.random() * 12));
      const states = ['NOMINAL', 'TELEMETRY OK', 'AI SYNCED', 'TRACK OPEN'];
      setTelemetryState(states[Math.floor(Math.random() * states.length)]);
    }, 2500);

    const handleResize = () => {
      if (!currentMount) return;
      const newWidth = currentMount.clientWidth;
      const newHeight = currentMount.clientHeight;
      camera.aspect = newWidth / newHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, newHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      clearInterval(speedInterval);
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
      if (currentMount.contains(renderer.domElement)) {
        currentMount.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  return (
    <div className="relative w-full h-[550px] md:h-[680px] rounded-2xl overflow-hidden glass-panel border border-cyan-500/30">
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      <div className="absolute top-6 left-6 flex flex-wrap gap-3 pointer-events-none">
        <div className="glass-panel px-4 py-2 flex items-center gap-2 border border-cyan-400/40 bg-slate-950/80 backdrop-blur-md">
          <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
          <span className="text-xs font-mono-tech tracking-wider text-cyan-300">LIVE TELEMETRY: {telemetryState}</span>
        </div>
        <div className="glass-panel px-4 py-2 flex items-center gap-2 border border-blue-400/40 bg-slate-950/80 backdrop-blur-md">
          <span className="text-xs font-mono-tech text-slate-300">SPEED:</span>
          <span className="text-sm font-bold text-glow-cyan font-mono-tech">{speedDisplay} KM/H</span>
        </div>
      </div>

      <div className="absolute top-6 right-6 pointer-events-none">
        <div className="glass-panel px-4 py-2 border border-purple-500/40 bg-slate-950/80 backdrop-blur-md text-right">
          <p className="text-[10px] text-purple-300 font-mono-tech tracking-widest uppercase">LOCOMOTIVE MODEL</p>
          <p className="text-xs font-bold text-slate-100 font-mono-tech">IR-WAP7 CYBER-X</p>
        </div>
      </div>

      <div className="absolute bottom-6 left-6 right-6 pointer-events-none flex justify-between items-end">
        <div className="hidden sm:flex flex-col gap-1 text-[11px] font-mono-tech text-cyan-400/80 bg-slate-950/60 p-3 rounded-lg border border-cyan-500/20 backdrop-blur-md">
          <div>TRACK_LATENCY: 1.2ms</div>
          <div>SIGNAL_QUEUE: OPTIMAL</div>
          <div>MODEL: XGBoost_IRCTC_v4.2</div>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-400 font-mono-tech bg-slate-950/70 px-4 py-2 rounded-full border border-slate-700">
          <span>🎮 Click & Drag to Orbit Camera</span>
        </div>
      </div>
    </div>
  );
};
