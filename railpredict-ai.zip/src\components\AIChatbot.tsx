import React, { useState, useRef, useEffect } from 'react';
import { X, Send, Bot, User, Radio, RefreshCw } from 'lucide-react';

interface Message {
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
}

interface AIChatbotProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AIChatbot: React.FC<AIChatbotProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: 'ai',
      text: 'Greetings! I am RailMind AI, your futuristic Indian Railways delay assistant. Ask me about any train schedule, fog weather forecasts, or corridor bottleneck status.',
      timestamp: 'Just now'
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const quickPrompts = [
    "Will my train be delayed?",
    "Is 12951 Rajdhani on time tomorrow?",
    "Why is Delhi-Howrah corridor delayed?",
    "What is the fog index in Northern Railway?"
  ];

  const handleSend = (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim()) return;

    const userMsg: Message = {
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInput('');
    setIsTyping(true);

    setTimeout(() => {
      let aiResponseText = "Based on historical patterns and weather conditions, your train may arrive 25 minutes late due to mild fog density on the Northern corridor.";

      const lower = query.toLowerCase();
      if (lower.includes('rajdhani') || lower.includes('12951')) {
        aiResponseText = "12951 Mumbai Rajdhani Express is currently operating at 94% punctuality score. Predicted delay for tomorrow is 15-18 minutes maximum.";
      } else if (lower.includes('fog') || lower.includes('weather')) {
        aiResponseText = "Satellite infrared telemetry indicates a dense fog blanket between Kanpur and Pt. Deen Dayal Upadhyaya Junction, reducing train speeds to 60 km/h.";
      } else if (lower.includes('howrah') || lower.includes('delhi')) {
        aiResponseText = "The Howrah-Delhi trunk line is currently experiencing heavy freight crossover traffic at Gaya Junction, creating a 35-minute queue buffer.";
      } else if (lower.includes('vande bharat') || lower.includes('20901')) {
        aiResponseText = "Vande Bharat Express services hold top signaling priority on all zones. Current predicted delay is 0 to 5 minutes.";
      }

      const aiMsg: Message = {
        sender: 'ai',
        text: aiResponseText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, aiMsg]);
      setIsTyping(false);
    }, 1200);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 w-full max-w-md bg-slate-950/95 backdrop-blur-2xl border border-cyan-500/40 rounded-2xl shadow-2xl shadow-cyan-950/60 overflow-hidden flex flex-col h-[560px] animate-fade-in">
      
      {/* Chat Header */}
      <div className="bg-slate-900/90 px-4 py-3.5 border-b border-cyan-500/30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center">
            <Bot className="w-5 h-5 text-cyan-400" />
            <span className="w-2 h-2 rounded-full bg-emerald-400 absolute bottom-0 right-0 animate-ping" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100 font-mono-tech">RailMind AI Assistant</h3>
            <p className="text-[10px] text-cyan-400 font-mono-tech flex items-center gap-1">
              <Radio className="w-3 h-3 text-emerald-400" /> ACTIVE TELEMETRY BOT
            </p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-100 border border-slate-700"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Messages List */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`flex items-start gap-2.5 ${msg.sender === 'user' ? 'flex-row-reverse' : ''}`}
          >
            <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs shrink-0 ${
              msg.sender === 'user' 
                ? 'bg-blue-600 text-white' 
                : 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
            }`}>
              {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>

            <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-xs leading-relaxed ${
              msg.sender === 'user'
                ? 'bg-blue-600 text-white font-medium rounded-tr-none'
                : 'bg-slate-900/90 text-slate-200 border border-slate-800 rounded-tl-none font-mono-tech'
            }`}>
              <p>{msg.text}</p>
              <span className="text-[9px] text-slate-400 block text-right mt-1.5 font-mono-tech">{msg.timestamp}</span>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex items-center gap-2 text-xs text-cyan-400 font-mono-tech p-2">
            <RefreshCw className="w-4 h-4 animate-spin" />
            RailMind is calculating ML delay probability...
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Suggestion Chips */}
      <div className="px-4 py-2 bg-slate-950 border-t border-slate-800/80 flex gap-2 overflow-x-auto no-scrollbar">
        {quickPrompts.map((prompt, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(prompt)}
            className="px-2.5 py-1 rounded-full bg-slate-900 hover:bg-cyan-500/20 text-slate-300 hover:text-cyan-300 border border-slate-800 text-[10px] font-mono-tech whitespace-nowrap transition-colors"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Input Box */}
      <div className="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Ask RailMind about train delays..."
          className="flex-1 bg-slate-950 text-slate-100 text-xs px-3.5 py-2.5 rounded-xl border border-slate-800 focus:outline-none focus:border-cyan-400 font-mono-tech"
        />
        <button
          onClick={() => handleSend()}
          className="p-2.5 rounded-xl bg-cyan-500 text-slate-950 hover:bg-cyan-400 font-bold transition-all shadow-md shadow-cyan-500/20"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>

    </div>
  );
};
