# 🚆 RailPredict AI — Futuristic Indian Railways Delay Prediction System

![RailPredict AI Banner](/public/futuristic_indian_train.jpg)

[![React 18](https://img.shields.io/badge/React-18.3-blue.svg?logo=react)](https://react.dev/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.2-3178C6.svg?logo=typescript)](https://www.typescriptlang.org/)
[![Vite](https://img.shields.io/badge/Vite-8.1-646CFF.svg?logo=vite)](https://vitejs.dev/)
[![Three.js](https://img.shields.io/badge/Three.js-0.160-black.svg?logo=three.js)](https://threejs.org/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-4.0-38B2AC.svg?logo=tailwind-css)](https://tailwindcss.com/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

> **RailPredict AI** is a next-generation (Year 2050-style) Indian Railways AI-powered delay prediction command center. Built with React 18, WebGL 3D locomotive rendering, XGBoost machine learning algorithms, and interactive spatial network visualizers.

---

## 📌 Short Repository Description (For GitHub About Section)

> **"Next-gen AI-powered Indian Railways Train Delay Prediction command center featuring 3D WebGL locomotive rendering, XGBoost ML forecasting, holographic analytics dashboard, and interactive spatial India map."**

---

## 📖 Table of Contents

- [Key Features](#-key-features)
- [Design Aesthetics](#-design-aesthetics)
- [Technology Stack](#-technology-stack)
- [Quick Start & Installation](#-quick-start--installation)
- [Project Architecture](#-project-architecture)
- [AI & Telemetry Pipeline](#-ai--telemetry-pipeline)
- [Screenshots & Visuals](#-screenshots--visuals)
- [License](#-license)

---

## ✨ Key Features

### 1. 🚄 3D WebGL Locomotive Visualizer
- Hardware-accelerated 3D rendering of the **IR-WAP7 Cyber-X** electric locomotive using **Three.js**.
- Features metallic body shaders, blue neon light trails, dual high-beam LED headlights, pantograph electric arcs, speed particle field, and camera orbit controls.
- Toggle between **3D WebGL Simulation** and **High-Resolution Futuristic Train Photograph** modes.

### 2. 🤖 AI Delay Inference Engine
- Interactive train prediction glass card supporting premier Indian trains (*12951 Mumbai Rajdhani*, *20901 Vande Bharat*, *12002 Shatabdi*, *12301 Howrah Rajdhani*, etc.).
- Animated telemetry scanning sequence evaluating satellite fog index, track congestion queues, and historical speed variance.
- Outputs predicted delay in minutes, probability confidence score, risk severity badge, and contributing delay factor breakdown.

### 3. 📊 Holographic SaaS Command Center Dashboard
- 4 Live Metric Hologram Cards: **Total Trains (13,000+)**, **Prediction Accuracy (92%)**, **Average Delay (28 Mins)**, **Live Predictions (2,500+)**.
- Interactive **Recharts** visualizations:
  - 24-Hour Predicted vs. Actual Delay Timeline Graph
  - Zone Punctuality Analytics (NR, WR, ER, SR, CR)
  - Meteorological Weather & Bottleneck Impact Radar Chart
  - Live Route Congestion Heatmap Matrix

### 4. 🗺️ Interactive Spatial India Railway Map
- SVG/Canvas map of India displaying major Golden Quadrilateral trunk corridors and station nodes (Delhi, Mumbai, Howrah, Chennai, Bengaluru, Ahmedabad, Varanasi).
- Real-time station telemetry, daily train flow counters, approaching trains, and map layer overlays for **Trunk Routes**, **Delay Hotspots**, and **Dense Fog Zones**.

### 5. 📚 Train Database & Spec Directory
- Photographic gallery of premier Indian trains with filter tabs (Vande Bharat, Rajdhani, Shatabdi, Superfast).
- Comprehensive detail modal featuring coach composition breakdown, speed specs, running days, and station-by-station delay risk timetables.

### 6. 💬 RailMind AI Chatbot Assistant
- Floating holographic assistant providing natural language responses to train delay queries, weather forecasts, and route congestion status.

---

## 🎨 Design Aesthetics

- **Theme**: Dark Cyberpunk / Antigravity Futuristic SaaS Command Center (`#030712`, `#0a0f24`).
- **Styling**: Glassmorphism UI panels with backdrop blur, glowing neon cyan (`#00f2fe`) and blue (`#4facfe`) borders.
- **Typography**: `Outfit` (sans-serif) for high-end headers and `JetBrains Mono` for monospace telemetry data.
- **Micro-Interactions**: Floating neon cards, glowing hover effects, pulsing signal lights, and smooth parallax scrolling.

---

## 🛠️ Technology Stack

| Layer | Technology |
| :--- | :--- |
| **Frontend UI** | React 18, TypeScript, Vite 8 |
| **Styling** | Tailwind CSS 4, Glassmorphism, CSS Custom Properties |
| **3D Rendering** | Three.js (WebGL Canvas) |
| **Data Visualization** | Recharts, Custom SVG Spatial Maps |
| **Icons** | Lucide React |
| **Machine Learning (Simulated)** | XGBoost Gradient Boosting, LSTM Neural Networks, LightGBM |
| **Backend Architecture** | Python 3.11, FastAPI, MongoDB TimeSeries |

---

## 🚀 Quick Start & Installation

### Prerequisites

- **Node.js**: v18.0.0 or higher
- **npm**: v9.0.0 or higher

### Steps

1. **Clone the Repository**:
   ```bash
   git clone https://github.com/your-username/railpredict-ai.git
   cd railpredict-ai
   ```

2. **Install Dependencies**:
   ```bash
   npm install
   ```

3. **Start the Development Server**:
   ```bash
   npm run dev
   ```

4. **Open in Browser**:
   Navigate to [http://localhost:5173/](http://localhost:5173/)

5. **Build for Production**:
   ```bash
   npm run build
   ```

---

## 📁 Project Architecture

```
railpredict-ai/
├── public/
│   ├── futuristic_indian_train.jpg  # Generated high-res train asset
│   └── vite.svg
├── src/
│   ├── components/
│   │   ├── AIChatbot.tsx            # RailMind AI Assistant Drawer
│   │   ├── Dashboard.tsx            # Holographic SaaS Analytics & Recharts
│   │   ├── Footer.tsx               # Futuristic Footer & System Status
│   │   ├── Hero.tsx                 # Main Hero Header & Visual Switcher
│   │   ├── IndiaMap.tsx             # Interactive Spatial SVG India Map
│   │   ├── Navbar.tsx               # Glassmorphism Top Navigation Header
│   │   ├── Predictor.tsx            # AI Delay Calculation Engine
│   │   ├── TechStack.tsx            # Technology Stack Cards
│   │   ├── Train3DCanvas.tsx        # Three.js 3D Locomotive Renderer
│   │   └── TrainDirectory.tsx       # Train Spec Gallery & Modals
│   ├── data/
│   │   └── trainData.ts             # Indian Railways dataset & telemetry specs
│   ├── App.tsx                      # Main Application Component
│   ├── index.css                    # Tailwind CSS v4 & Glassmorphism system
│   ├── main.tsx                     # Entry point
│   └── vite-env.d.ts
├── index.html                       # HTML5 Root with SEO Metadata
├── package.json                     # Dependencies & Scripts
├── tailwind.config.js               # Tailwind Configuration
├── tsconfig.json                    # TypeScript Configuration
└── vite.config.ts                   # Vite Bundler Configuration
```

---

## 🧠 AI & Telemetry Pipeline

The **RailPredict AI** engine factors four primary data inputs:
1. **Locomotive Telemetry**: Real-time GPS coordinates, current velocity, and signal stop history.
2. **Meteorological Grid**: Satellite fog index, ambient temperature, monsoon precipitation levels.
3. **Signal & Freight Queues**: Track occupancy matrices and freight crossover priority scores.
4. **Historical Punctuality**: 10-year same-day IRCTC arrival variance curves analyzed via **XGBoost Decision Trees**.

---

## 📄 License

This project is licensed under the **MIT License** — see the [LICENSE](LICENSE) file for details.

---

<p center>
  Designed & Engineered with ❤️ for <strong>Indian Railways & Modern Transportation</strong>.
</p>
