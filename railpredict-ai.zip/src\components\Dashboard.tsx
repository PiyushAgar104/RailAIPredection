import React, { useState } from 'react';
import { 
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar 
} from 'recharts';
import { Train, Activity, Clock, ShieldCheck, Zap, CloudFog, Thermometer, Wind } from 'lucide-react';

const delayTrendData = [
  { time: '02:00', predicted: 18, actual: 16 },
  { time: '06:00', predicted: 24, actual: 28 },
  { time: '10:00', predicted: 35, actual: 32 },
  { time: '14:00', predicted: 22, actual: 25 },
  { time: '18:00', predicted: 42, actual: 40 },
  { time: '22:00', predicted: 28, actual: 29 },
];

const zonePerformanceData = [
  { zone: 'NR (Northern)', punctuality: 84, avgDelay: 32 },
  { zone: 'WR (Western)', punctuality: 96, avgDelay: 12 },
  { zone: 'ER (Eastern)', punctuality: 88, avgDelay: 24 },
  { zone: 'SR (Southern)', punctuality: 94, avgDelay: 14 },
  { zone: 'CR (Central)', punctuality: 90, avgDelay: 20 },
];

const weatherImpactData = [
  { factor: 'Dense Fog', impact: 85 },
  { factor: 'Monsoon Rain', impact: 65 },
  { factor: 'Heat Wave', impact: 40 },
  { factor: 'Track Maintenance', impact: 70 },
  { factor: 'Freight Congestion', impact: 90 },
];

export const Dashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'trends' | 'zones' | 'weather'>('trends');

  return (
    <section id="dashboard" className="py-24 relative overflow-hidden bg-slate-950">
      
      {/* Ambient background glow */}
      <div className="absolute top-1/2 right-10 w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-mono-tech">
            <Activity className="w-4 h-4 text-cyan-400" />
            REAL-TIME COMMAND CENTER DASHBOARD
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-slate-100">
            Holographic <span className="text-gradient">Railway Analytics</span>
          </h2>
          <p className="text-slate-400 text-base sm:text-lg">
            Next-gen SaaS dashboard monitoring pan-Indian railway operations, network bottlenecks, and machine learning accuracy metrics.
          </p>
        </div>

        {/* 4 Hero Stat Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          
          {/* Card 1: Total Trains */}
          <div className="glass-card-interactive p-6 border border-cyan-500/30 relative overflow-hidden group hover:scale-[1.02] transition-all">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono-tech text-slate-400 uppercase tracking-wider">TOTAL TRAINS</span>
              <div className="p-3 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 group-hover:rotate-12 transition-transform">
                <Train className="w-6 h-6" />
              </div>
            </div>
            <div className="text-3xl font-extrabold text-slate-100 font-mono-tech">13,000+</div>
            <div className="flex items-center gap-2 mt-2 text-xs text-emerald-400 font-mono-tech">
              <span>↑ 4.2% Active Fleet</span>
            </div>
          </div>

          {/* Card 2: Prediction Accuracy */}
          <div className="glass-card-interactive p-6 border border-emerald-500/30 relative overflow-hidden group hover:scale-[1.02] transition-all">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono-tech text-slate-400 uppercase tracking-wider">PREDICTION ACCURACY</span>
              <div className="p-3 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 group-hover:rotate-12 transition-transform">
                <ShieldCheck className="w-6 h-6" />
              </div>
            </div>
            <div className="text-3xl font-extrabold text-emerald-400 font-mono-tech">92%</div>
            <div className="flex items-center gap-2 mt-2 text-xs text-slate-400 font-mono-tech">
              <span>XGBoost + LSTM Neural Net</span>
            </div>
          </div>

          {/* Card 3: Average Delay */}
          <div className="glass-card-interactive p-6 border border-amber-500/30 relative overflow-hidden group hover:scale-[1.02] transition-all">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono-tech text-slate-400 uppercase tracking-wider">AVERAGE DELAY</span>
              <div className="p-3 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 group-hover:rotate-12 transition-transform">
                <Clock className="w-6 h-6" />
              </div>
            </div>
            <div className="text-3xl font-extrabold text-amber-400 font-mono-tech">28 <span className="text-lg font-normal text-slate-300">MINS</span></div>
            <div className="flex items-center gap-2 mt-2 text-xs text-emerald-400 font-mono-tech">
              <span>↓ 8.5 Mins vs 2023 Avg</span>
            </div>
          </div>

          {/* Card 4: Live Predictions */}
          <div className="glass-card-interactive p-6 border border-purple-500/30 relative overflow-hidden group hover:scale-[1.02] transition-all">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono-tech text-slate-400 uppercase tracking-wider">LIVE PREDICTIONS</span>
              <div className="p-3 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30 group-hover:rotate-12 transition-transform">
                <Zap className="w-6 h-6" />
              </div>
            </div>
            <div className="text-3xl font-extrabold text-purple-400 font-mono-tech">2,500+</div>
            <div className="flex items-center gap-2 mt-2 text-xs text-cyan-400 font-mono-tech">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              <span>Streaming WebSockets</span>
            </div>
          </div>

        </div>

        {/* Dashboard Main Visualizer Panel */}
        <div className="glass-card-interactive p-6 sm:p-8 border border-cyan-500/30 space-y-6">
          
          {/* Tab Navigation Controls */}
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setActiveTab('trends')}
                className={`px-4 py-2 rounded-xl text-xs font-bold font-mono-tech transition-all ${
                  activeTab === 'trends'
                    ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/30'
                    : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
                }`}
              >
                24H DELAY PREDICTION GRAPH
              </button>
              <button
                onClick={() => setActiveTab('zones')}
                className={`px-4 py-2 rounded-xl text-xs font-bold font-mono-tech transition-all ${
                  activeTab === 'zones'
                    ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/30'
                    : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
                }`}
              >
                ZONE PUNCTUALITY ANALYTICS
              </button>
              <button
                onClick={() => setActiveTab('weather')}
                className={`px-4 py-2 rounded-xl text-xs font-bold font-mono-tech transition-all ${
                  activeTab === 'weather'
                    ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/30'
                    : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
                }`}
              >
                WEATHER & BOTTLENECK IMPACT
              </button>
            </div>

            <span className="text-xs font-mono-tech text-slate-400 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              UDP TELEMETRY FEED
            </span>
          </div>

          {/* Tab 1: Delay Prediction Graph (Recharts Area Chart) */}
          {activeTab === 'trends' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center text-xs font-mono-tech text-slate-400">
                <span>PREDICTED VS ACTUAL DELAY (MINUTES) ACROSS 24-HOUR TIMELINE</span>
                <div className="flex gap-4">
                  <span className="text-cyan-400 flex items-center gap-1">■ Predicted</span>
                  <span className="text-purple-400 flex items-center gap-1">■ Actual Telemetry</span>
                </div>
              </div>

              <div className="h-72 w-full pt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={delayTrendData}>
                    <defs>
                      <linearGradient id="colorPred" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#00f2fe" stopOpacity={0.4}/>
                        <stop offset="95%" stopColor="#00f2fe" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorActual" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#a855f7" stopOpacity={0.4}/>
                        <stop offset="95%" stopColor="#a855f7" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="time" stroke="#64748b" />
                    <YAxis stroke="#64748b" />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#090d16', borderColor: '#00f2fe', borderRadius: '0.5rem' }}
                      itemStyle={{ color: '#f3f4f6', fontFamily: 'JetBrains Mono' }}
                    />
                    <Area type="monotone" dataKey="predicted" stroke="#00f2fe" strokeWidth={3} fillOpacity={1} fill="url(#colorPred)" />
                    <Area type="monotone" dataKey="actual" stroke="#a855f7" strokeWidth={2} fillOpacity={1} fill="url(#colorActual)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Tab 2: Zone Performance Bar Chart */}
          {activeTab === 'zones' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center text-xs font-mono-tech text-slate-400">
                <span>PUNCTUALITY SCORE (%) BY INDIAN RAILWAY ZONES</span>
              </div>

              <div className="h-72 w-full pt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={zonePerformanceData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="zone" stroke="#64748b" />
                    <YAxis stroke="#64748b" domain={[0, 100]} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#090d16', borderColor: '#4facfe', borderRadius: '0.5rem' }}
                      itemStyle={{ color: '#f3f4f6', fontFamily: 'JetBrains Mono' }}
                    />
                    <Bar dataKey="punctuality" fill="#00f2fe" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Tab 3: Weather Radar Impact */}
          {activeTab === 'weather' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart cx="50%" cy="50%" outerRadius="80%" data={weatherImpactData}>
                    <PolarGrid stroke="#1e293b" />
                    <PolarAngleAxis dataKey="factor" stroke="#94a3b8" />
                    <PolarRadiusAxis stroke="#64748b" />
                    <Radar name="Impact Index" dataKey="impact" stroke="#00f2fe" fill="#00f2fe" fillOpacity={0.4} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>

              <div className="space-y-4">
                <h4 className="text-sm font-bold text-slate-100 font-mono-tech">AI ENVIRONMENTAL RISK METRICS</h4>
                <div className="space-y-3">
                  <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 flex items-center gap-3">
                    <CloudFog className="w-6 h-6 text-cyan-400" />
                    <div>
                      <h5 className="text-xs font-bold text-slate-200">Northern Fog Warning</h5>
                      <p className="text-[11px] text-slate-400">Delhi-Kanpur section visibility reduced to &lt; 50 meters</p>
                    </div>
                  </div>

                  <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 flex items-center gap-3">
                    <Thermometer className="w-6 h-6 text-amber-400" />
                    <div>
                      <h5 className="text-xs font-bold text-slate-200">Track Expansion Sensor</h5>
                      <p className="text-[11px] text-slate-400">High ambient heat monitoring on Western corridor rails</p>
                    </div>
                  </div>

                  <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 flex items-center gap-3">
                    <Wind className="w-6 h-6 text-emerald-400" />
                    <div>
                      <h5 className="text-xs font-bold text-slate-200">Coastal Wind Speed Gauge</h5>
                      <p className="text-[11px] text-slate-400">Normal operating parameters along Southern coastal tracks</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Route Congestion Heatmap Grid */}
          <div className="pt-4 border-t border-slate-800">
            <h4 className="text-xs font-mono-tech text-slate-400 uppercase tracking-wider mb-3">
              LIVE ROUTE CONGESTION HEATMAP
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { route: 'Delhi - Mumbai', status: 'Moderate Traffic', level: 'bg-amber-500/20 text-amber-400 border-amber-500/30' },
                { route: 'Howrah - Delhi', status: 'High Bottleneck', level: 'bg-rose-500/20 text-rose-400 border-rose-500/30' },
                { route: 'Chennai - Bengaluru', status: 'Clear Corridor', level: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' },
                { route: 'Mumbai - Ahmedabad', status: 'Optimal (VB)', level: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30' }
              ].map((r, i) => (
                <div key={i} className={`p-3 rounded-xl border ${r.level} font-mono-tech text-xs space-y-1`}>
                  <p className="font-bold text-slate-200">{r.route}</p>
                  <p className="text-[11px] font-normal">{r.status}</p>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
