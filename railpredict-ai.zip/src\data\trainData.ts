export interface TrainInfo {
  id: string;
  number: string;
  name: string;
  type: 'Vande Bharat' | 'Rajdhani' | 'Shatabdi' | 'Tejas' | 'Superfast' | 'Duronto';
  source: string;
  destination: string;
  sourceCode: string;
  destCode: string;
  distanceKm: number;
  avgSpeedKmh: number;
  maxSpeedKmh: number;
  runningDays: string[];
  departureTime: string;
  arrivalTime: string;
  avgDelayMins: number;
  reliabilityScore: number;
  coaches: { type: string; count: number }[];
  routeStations: { name: string; code: string; day: number; time: string; delayRisk: 'Low' | 'Medium' | 'High' }[];
  image: string;
  description: string;
}

export const INDIAN_TRAINS: TrainInfo[] = [
  {
    id: '20901',
    number: '20901',
    name: 'Vande Bharat Express (Mumbai - Gandhinagar)',
    type: 'Vande Bharat',
    source: 'Mumbai Central',
    destination: 'Gandhinagar Capital',
    sourceCode: 'MMCT',
    destCode: 'GNC',
    distanceKm: 522,
    avgSpeedKmh: 83,
    maxSpeedKmh: 160,
    runningDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    departureTime: '06:00',
    arrivalTime: '12:25',
    avgDelayMins: 6,
    reliabilityScore: 98,
    coaches: [
      { type: 'Executive Chair Car (EC)', count: 2 },
      { type: 'AC Chair Car (CC)', count: 14 }
    ],
    routeStations: [
      { name: 'Mumbai Central', code: 'MMCT', day: 1, time: '06:00', delayRisk: 'Low' },
      { name: 'Vapi', code: 'VAPI', day: 1, time: '07:30', delayRisk: 'Low' },
      { name: 'Surat', code: 'ST', day: 1, time: '08:37', delayRisk: 'Low' },
      { name: 'Vadodara Jn', code: 'BRC', day: 1, time: '10:13', delayRisk: 'Low' },
      { name: 'Ahmedabad Jn', code: 'ADI', day: 1, time: '11:25', delayRisk: 'Low' },
      { name: 'Gandhinagar Capital', code: 'GNC', day: 1, time: '12:25', delayRisk: 'Low' }
    ],
    image: '/futuristic_indian_train.jpg',
    description: 'Next-generation indigenous semi-high speed train with aerodynamically designed nose, automatic doors, and 160 km/h capability.'
  },
  {
    id: '12951',
    number: '12951',
    name: 'Mumbai Rajdhani Express',
    type: 'Rajdhani',
    source: 'Mumbai Central',
    destination: 'New Delhi',
    sourceCode: 'MMCT',
    destCode: 'NDLS',
    distanceKm: 1386,
    avgSpeedKmh: 88,
    maxSpeedKmh: 130,
    runningDays: ['Daily'],
    departureTime: '17:00',
    arrivalTime: '08:32 (+1 day)',
    avgDelayMins: 18,
    reliabilityScore: 94,
    coaches: [
      { type: '1st AC (1A)', count: 1 },
      { type: '2nd AC (2A)', count: 5 },
      { type: '3rd AC (3A)', count: 11 },
      { type: 'Pantry Car (PC)', count: 1 }
    ],
    routeStations: [
      { name: 'Mumbai Central', code: 'MMCT', day: 1, time: '17:00', delayRisk: 'Low' },
      { name: 'Surat', code: 'ST', day: 1, time: '19:48', delayRisk: 'Low' },
      { name: 'Vadodara Jn', code: 'BRC', day: 1, time: '21:16', delayRisk: 'Low' },
      { name: 'Ratlam Jn', code: 'RTM', day: 2, time: '00:35', delayRisk: 'Medium' },
      { name: 'Kota Jn', code: 'KOTA', day: 2, time: '03:15', delayRisk: 'Medium' },
      { name: 'New Delhi', code: 'NDLS', day: 2, time: '08:32', delayRisk: 'Low' }
    ],
    image: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?q=80&w=1200&auto=format&fit=crop',
    description: 'Premier high-speed train connecting India\'s financial capital to the national capital with top-tier punctuality and LHB coaches.'
  },
  {
    id: '12002',
    number: '12002',
    name: 'New Delhi - Bhopal Shatabdi Express',
    type: 'Shatabdi',
    source: 'New Delhi',
    destination: 'Rani Kamlapati (Bhopal)',
    sourceCode: 'NDLS',
    destCode: 'RKMP',
    distanceKm: 707,
    avgSpeedKmh: 84,
    maxSpeedKmh: 150,
    runningDays: ['Daily'],
    departureTime: '06:00',
    arrivalTime: '14:40',
    avgDelayMins: 14,
    reliabilityScore: 92,
    coaches: [
      { type: 'Anubhuti Class (EA)', count: 1 },
      { type: 'Executive Class (EC)', count: 2 },
      { type: 'AC Chair Car (CC)', count: 12 }
    ],
    routeStations: [
      { name: 'New Delhi', code: 'NDLS', day: 1, time: '06:00', delayRisk: 'Low' },
      { name: 'Mathura Jn', code: 'MTJ', day: 1, time: '07:19', delayRisk: 'Medium' },
      { name: 'Agra Cantt', code: 'AGC', day: 1, time: '07:50', delayRisk: 'Low' },
      { name: 'Gwalior Jn', code: 'GWL', day: 1, time: '09:23', delayRisk: 'Low' },
      { name: 'VGL Jhansi Jn', code: 'VGLJ', day: 1, time: '10:45', delayRisk: 'Low' },
      { name: 'Rani Kamlapati', code: 'RKMP', day: 1, time: '14:40', delayRisk: 'Low' }
    ],
    image: 'https://images.unsplash.com/photo-1515165562839-97840139158d?q=80&w=1200&auto=format&fit=crop',
    description: 'One of the fastest day trains in India operating on the WCR/NCR speed corridor with high-frequency telemetry tracking.'
  },
  {
    id: '22436',
    number: '22436',
    name: 'Vande Bharat Express (New Delhi - Varanasi)',
    type: 'Vande Bharat',
    source: 'New Delhi',
    destination: 'Varanasi Jn',
    sourceCode: 'NDLS',
    destCode: 'BSB',
    distanceKm: 759,
    avgSpeedKmh: 95,
    maxSpeedKmh: 160,
    runningDays: ['Tue', 'Wed', 'Fri', 'Sat', 'Sun'],
    departureTime: '06:00',
    arrivalTime: '14:00',
    avgDelayMins: 4,
    reliabilityScore: 99,
    coaches: [
      { type: 'Executive Chair Car (EC)', count: 2 },
      { type: 'AC Chair Car (CC)', count: 14 }
    ],
    routeStations: [
      { name: 'New Delhi', code: 'NDLS', day: 1, time: '06:00', delayRisk: 'Low' },
      { name: 'Kanpur Central', code: 'CNB', day: 1, time: '10:08', delayRisk: 'Low' },
      { name: 'Prayagraj Jn', code: 'PRYJ', day: 1, time: '12:08', delayRisk: 'Low' },
      { name: 'Varanasi Jn', code: 'BSB', day: 1, time: '14:00', delayRisk: 'Low' }
    ],
    image: '/futuristic_indian_train.jpg',
    description: 'India\'s flagship first Vande Bharat service boasting zero engine delays and real-time regenerative braking telemetry.'
  }
];

export const MAJOR_STATIONS = [
  { name: 'New Delhi', code: 'NDLS', state: 'Delhi', lat: 28.6448, lng: 77.2167 },
  { name: 'Mumbai Central', code: 'MMCT', state: 'Maharashtra', lat: 18.9696, lng: 72.8193 },
  { name: 'Howrah Junction', code: 'HWH', state: 'West Bengal', lat: 22.5851, lng: 88.3412 },
  { name: 'Chennai Central', code: 'MAS', state: 'Tamil Nadu', lat: 13.0827, lng: 80.2707 },
  { name: 'KSR Bengaluru', code: 'SBC', state: 'Karnataka', lat: 12.9774, lng: 77.5708 },
  { name: 'Ahmedabad Junction', code: 'ADI', state: 'Gujarat', lat: 23.0225, lng: 72.5714 },
  { name: 'Kanpur Central', code: 'CNB', state: 'Uttar Pradesh', lat: 26.4542, lng: 80.3500 },
  { name: 'Pt. Deen Dayal Upadhyaya', code: 'DDU', state: 'Uttar Pradesh', lat: 25.2818, lng: 83.1186 },
  { name: 'Varanasi Junction', code: 'BSB', state: 'Uttar Pradesh', lat: 25.3176, lng: 82.9739 },
  { name: 'Hyderabad Deccan', code: 'HYB', state: 'Telangana', lat: 17.3850, lng: 78.4867 }
];

export const TECH_FEATURES = [
  {
    name: 'Machine Learning',
    tech: 'Scikit-Learn & LightGBM',
    tag: 'ML Core',
    desc: 'Analyzes 10+ years of IRCTC arrival records, track occupancy, and signal stop logs to compute probabilistic delay curves.',
    icon: 'Brain'
  },
  {
    name: 'Python Engine',
    tech: 'Python 3.11 & NumPy',
    tag: 'Backend Core',
    desc: 'High-throughput data ingestion processing 50,000 active train telemetry updates per minute across Indian rail zones.',
    icon: 'Code2'
  },
  {
    name: 'FastAPI Microservice',
    tech: 'Asynchronous REST & WebSockets',
    tag: 'High Speed API',
    desc: 'Sub-15ms response latency for live delay inference and streaming WebSockets updates to client command dashboards.',
    icon: 'Zap'
  },
  {
    name: 'React 18 & Three.js',
    tech: 'TypeScript & WebGL',
    tag: 'Frontend SaaS',
    desc: 'Hardware-accelerated 3D train locomotive rendering, dynamic neon charts, and responsive glassmorphism UI.',
    icon: 'Layers'
  },
  {
    name: 'MongoDB Atlas',
    tech: 'TimeSeries Collections',
    tag: 'Data Persistence',
    desc: 'Scalable temporal database storing historical delays, weather telemetry, and route bottleneck matrices.',
    icon: 'Database'
  },
  {
    name: 'XGBoost Gradient Boosting',
    tech: 'Feature Importance AI',
    tag: 'Prediction Model',
    desc: 'State-of-the-art decision tree boosting factoring fog density, monsoon alerts, and freight train crossing priorities.',
    icon: 'TrendingUp'
  },
  {
    name: 'Deep Learning (LSTM)',
    tech: 'TensorFlow / PyTorch',
    tag: 'Time-Series Neural Net',
    desc: 'Recurrent neural networks modeling sequential track delays across multi-day pan-Indian transit corridors.',
    icon: 'Cpu'
  }
];
