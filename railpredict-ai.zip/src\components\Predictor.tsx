import React, { useState } from 'react';
import { INDIAN_TRAINS, type TrainInfo } from '../data/trainData';
import { Sparkles, Calendar, MapPin, Search, Cpu, RefreshCw } from 'lucide-react';

export const Predictor: React.FC = () => {
  const [selectedTrainNumber, setSelectedTrainNumber] = useState('12951');
  const [selectedTrain, setSelectedTrain] = useState<TrainInfo>(INDIAN_TRAINS[0]);
  const [sourceStation, setSourceStation] = useState(INDIAN_TRAINS[0].source);
  const [destStation, setDestStation] = useState(INDIAN_TRAINS[0].destination);
  const [journeyDate, setJourneyDate] = useState(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  });

  const [isScanning, setIsScanning] = useState(false);
  const [scanStep, setScanStep] = useState(0);
  const [predictionResult, setPredictionResult] = useState<{
    predictedDelayMins: number;
    probability: number;
    status: 'On-Time' | 'Minor Delay' | 'Likely Delayed' | 'Severe Delay';
    statusColor: string;
    factors: { label: string; percent: number; desc: string }[];
  } | null>({
    predictedDelayMins: 35,
    probability: 78,
    status: 'Likely Delayed',
    statusColor: 'text-amber-400 border-amber-500/40 bg-amber-500/10',
    factors: [
      { label: 'Fog & Monsoon Index', percent: 42, desc: 'Low visibility warnings across Northern Zone' },
      { label: 'Corridor Congestion', percent: 32, desc: 'Heavy freight train traffic on DDU-Kanpur trunk line' },
      { label: 'Historical Speed Lag', percent: 16, desc: 'Average 12 km/h slowdown near junction crossovers' },
      { label: 'Signal Priority Buffer', percent: 10, desc: 'High priority clearance assigned to Rajdhani' }
    ]
  });

  const handleTrainSelect = (trainNo: string) => {
    setSelectedTrainNumber(trainNo);
    const found = INDIAN_TRAINS.find(t => t.number === trainNo);
    if (found) {
      setSelectedTrain(found);
      setSourceStation(found.source);
      setDestStation(found.destination);
    }
  };

  const handlePredict = (e: React.FormEvent) => {
    e.preventDefault();
    setIsScanning(true);
    setScanStep(0);
    setPredictionResult(null);

    const steps = [
      'Ingesting real-time GPS telemetry & signal sensors...',
      'Analyzing satellite weather & fog density index...',
      'Evaluating active freight schedule & track congestion...',
      'Executing XGBoost decision trees & LSTM neural net...'
    ];

    let current = 0;
    const interval = setInterval(() => {
      current++;
      setScanStep(current);
      if (current >= steps.length) {
        clearInterval(interval);
        setTimeout(() => {
          const baseDelay = selectedTrain.avgDelayMins;
          const randomOffset = Math.floor(Math.random() * 15) - 5;
          const delayMins = Math.max(0, baseDelay + randomOffset);

          let status: 'On-Time' | 'Minor Delay' | 'Likely Delayed' | 'Severe Delay' = 'Likely Delayed';
          let statusColor = 'text-amber-400 border-amber-500/40 bg-amber-500/10';

          if (delayMins < 10) {
            status = 'On-Time';
            statusColor = 'text-emerald-400 border-emerald-500/40 bg-emerald-500/10';
          } else if (delayMins < 25) {
            status = 'Minor Delay';
            statusColor = 'text-cyan-400 border-cyan-500/40 bg-cyan-500/10';
          } else if (delayMins > 45) {
            status = 'Severe Delay';
            statusColor = 'text-rose-400 border-rose-500/40 bg-rose-500/10';
          }

          setPredictionResult({
            predictedDelayMins: delayMins,
            probability: Math.min(96, Math.max(65, 75 + Math.floor(Math.random() * 18))),
            status,
            statusColor,
            factors: [
              { label: 'Weather & Visibility', percent: 38 + Math.floor(Math.random() * 10), desc: 'Satellite cloud cover and humidity metrics' },
              { label: 'Track Congestion', percent: 30 + Math.floor(Math.random() * 8), desc: 'Active signal queue at major junction switches' },
              { label: 'Historical Variance', percent: 18, desc: '10-year same-day punctuality profile' },
              { label: 'Locomotive Health', percent: 14, desc: 'Smart sensor telemetry: 100% operational' }
            ]
          });
          setIsScanning(false);
        }, 500);
      }
    }, 700);
  };

  return (
    <section id="predictor" className="py-24 relative overflow-hidden bg-slate-950/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-mono-tech">
            <Cpu className="w-4 h-4 text-cyan-400 animate-spin" style={{ animationDuration: '10s' }} />
            AI DELAY INFERENCE ENGINE
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-slate-100">
            Train Delay <span className="text-gradient">Prediction Interface</span>
          </h2>
          <p className="text-slate-400 text-base sm:text-lg">
            Enter your train parameters to compute real-time arrival probabilities and estimated delay durations with 92%+ precision.
          </p>
        </div>

        {/* Prediction Glass Card Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Input Form Card */}
          <div className="lg:col-span-6 glass-card-interactive p-6 sm:p-8 border border-cyan-500/30 relative">
            <div className="flex items-center justify-between pb-6 mb-6 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                  <Search className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-100">Train Parameters</h3>
                  <p className="text-xs text-slate-400 font-mono-tech">IRCTC ACTIVE DIRECTORY</p>
                </div>
              </div>
              <span className="text-xs font-mono-tech text-cyan-400 bg-cyan-500/10 px-3 py-1 rounded-full border border-cyan-500/30">
                LIVE MODEL
              </span>
            </div>

            <form onSubmit={handlePredict} className="space-y-6">
              
              {/* Train Selection Dropdown */}
              <div>
                <label className="block text-xs font-mono-tech text-slate-300 uppercase tracking-wider mb-2">
                  Select / Search Train Number
                </label>
                <div className="relative">
                  <select
                    value={selectedTrainNumber}
                    onChange={(e) => handleTrainSelect(e.target.value)}
                    className="w-full bg-slate-900/90 text-slate-100 border border-cyan-500/30 rounded-xl px-4 py-3.5 pl-11 focus:outline-none focus:border-cyan-400 text-sm font-mono-tech appearance-none cursor-pointer"
                  >
                    {INDIAN_TRAINS.map((t) => (
                      <option key={t.id} value={t.number} className="bg-slate-900 text-slate-200">
                        {t.number} - {t.name} ({t.type})
                      </option>
                    ))}
                  </select>
                  <Search className="w-5 h-5 text-cyan-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>
              </div>

              {/* Source & Destination Station Inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono-tech text-slate-300 uppercase tracking-wider mb-2">
                    Source Station
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={sourceStation}
                      onChange={(e) => setSourceStation(e.target.value)}
                      className="w-full bg-slate-900/90 text-slate-100 border border-slate-700 rounded-xl px-4 py-3 pl-10 text-sm font-medium focus:outline-none focus:border-cyan-400"
                      placeholder="e.g. MMCT"
                    />
                    <MapPin className="w-4 h-4 text-emerald-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono-tech text-slate-300 uppercase tracking-wider mb-2">
                    Destination Station
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={destStation}
                      onChange={(e) => setDestStation(e.target.value)}
                      className="w-full bg-slate-900/90 text-slate-100 border border-slate-700 rounded-xl px-4 py-3 pl-10 text-sm font-medium focus:outline-none focus:border-cyan-400"
                      placeholder="e.g. NDLS"
                    />
                    <MapPin className="w-4 h-4 text-rose-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  </div>
                </div>
              </div>

              {/* Journey Date Picker */}
              <div>
                <label className="block text-xs font-mono-tech text-slate-300 uppercase tracking-wider mb-2">
                  Journey Date
                </label>
                <div className="relative">
                  <input
                    type="date"
                    value={journeyDate}
                    onChange={(e) => setJourneyDate(e.target.value)}
                    className="w-full bg-slate-900/90 text-slate-100 border border-slate-700 rounded-xl px-4 py-3 pl-10 text-sm font-medium focus:outline-none focus:border-cyan-400"
                  />
                  <Calendar className="w-4 h-4 text-cyan-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                </div>
              </div>

              {/* Selected Train Quick Profile Specs */}
              <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-2">
                <div className="flex justify-between text-xs text-slate-400">
                  <span>Category: <strong className="text-slate-200">{selectedTrain.type}</strong></span>
                  <span>Avg Speed: <strong className="text-cyan-400 font-mono-tech">{selectedTrain.avgSpeedKmh} KM/H</strong></span>
                </div>
                <div className="flex justify-between text-xs text-slate-400">
                  <span>Distance: <strong className="text-slate-200">{selectedTrain.distanceKm} KM</strong></span>
                  <span>Reliability: <strong className="text-emerald-400 font-mono-tech">{selectedTrain.reliabilityScore}%</strong></span>
                </div>
              </div>

              {/* Submit CTA Button */}
              <button
                type="submit"
                disabled={isScanning}
                className="w-full btn-neon-primary py-4 text-base font-bold rounded-xl flex items-center justify-center gap-3 shadow-lg shadow-cyan-500/30"
              >
                {isScanning ? (
                  <>
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    Calculating Telemetry...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5" />
                    Predict Delay
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Output Display Panel */}
          <div className="lg:col-span-6 min-h-[500px]">
            {isScanning && (
              <div className="glass-card-interactive p-8 border border-cyan-500/40 h-full flex flex-col justify-center items-center text-center space-y-6">
                <div className="relative w-24 h-24 flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full border-4 border-cyan-500/20 border-t-cyan-400 animate-spin" />
                  <Cpu className="w-10 h-10 text-cyan-400 animate-pulse" />
                </div>

                <div className="space-y-2">
                  <h4 className="text-xl font-bold text-slate-100 font-mono-tech">AI ENGINE SCANNING</h4>
                  <p className="text-xs text-cyan-400 font-mono-tech">PROCESSING NEURAL NETWORK INFERENCE</p>
                </div>

                <div className="w-full max-w-md bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-3">
                  {[
                    'Ingesting real-time GPS telemetry & signal sensors...',
                    'Analyzing satellite weather & fog density index...',
                    'Evaluating active freight schedule & track congestion...',
                    'Executing XGBoost decision trees & LSTM neural net...'
                  ].map((stepText, idx) => (
                    <div key={idx} className="flex items-center gap-3 text-left">
                      <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                        scanStep > idx ? 'bg-emerald-500 text-slate-950' : scanStep === idx ? 'bg-cyan-400 text-slate-950 animate-pulse' : 'bg-slate-800 text-slate-500'
                      }`}>
                        {scanStep > idx ? '✓' : idx + 1}
                      </div>
                      <span className={`text-xs font-mono-tech ${scanStep >= idx ? 'text-slate-200' : 'text-slate-600'}`}>
                        {stepText}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {predictionResult && !isScanning && (
              <div className="glass-card-interactive p-6 sm:p-8 border border-cyan-500/40 space-y-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />

                <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                  <div>
                    <span className="text-xs font-mono-tech text-slate-400">TARGET TRAIN</span>
                    <h3 className="text-xl font-bold text-slate-100">{selectedTrain.number} - {selectedTrain.name}</h3>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-bold font-mono-tech border ${predictionResult.statusColor}`}>
                    {predictionResult.status}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="glass-panel p-5 text-center border border-cyan-500/30">
                    <p className="text-xs text-slate-400 uppercase font-mono-tech">PREDICTED DELAY</p>
                    <p className="text-4xl font-extrabold text-glow-cyan font-mono-tech mt-2">
                      {predictionResult.predictedDelayMins} <span className="text-lg font-normal text-slate-300">MINS</span>
                    </p>
                    <p className="text-[11px] text-slate-400 mt-1">± 3 Mins Margin of Error</p>
                  </div>

                  <div className="glass-panel p-5 text-center border border-purple-500/30">
                    <p className="text-xs text-slate-400 uppercase font-mono-tech">PROBABILITY CONFIDENCE</p>
                    <p className="text-4xl font-extrabold text-purple-400 font-mono-tech mt-2">
                      {predictionResult.probability}%
                    </p>
                    <p className="text-[11px] text-slate-400 mt-1">XGBoost ML Confidence</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="text-xs font-mono-tech text-slate-400 uppercase tracking-wider">
                    CONTRIBUTING DELAY FACTORS
                  </h4>

                  {predictionResult.factors.map((factor, i) => (
                    <div key={i} className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 space-y-1.5">
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-semibold text-slate-200">{factor.label}</span>
                        <span className="font-mono-tech text-cyan-400 font-bold">{factor.percent}% impact</span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full"
                          style={{ width: `${factor.percent}%` }}
                        />
                      </div>
                      <p className="text-[11px] text-slate-400">{factor.desc}</p>
                    </div>
                  ))}
                </div>

                <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 space-y-2">
                  <span className="text-xs font-mono-tech text-slate-400 block mb-2">ROUTE CORRIDOR TELEMETRY</span>
                  <div className="grid grid-cols-3 text-[11px] font-mono-tech text-slate-400 pb-1 border-b border-slate-800">
                    <span>STATION</span>
                    <span>SCHED. TIME</span>
                    <span className="text-right">RISK</span>
                  </div>
                  {selectedTrain.routeStations.slice(0, 4).map((st, idx) => (
                    <div key={idx} className="grid grid-cols-3 text-xs items-center py-1">
                      <span className="text-slate-200 font-medium">{st.name} ({st.code})</span>
                      <span className="text-slate-400 font-mono-tech">{st.time}</span>
                      <span className={`text-right font-bold text-[11px] ${
                        st.delayRisk === 'Low' ? 'text-emerald-400' : st.delayRisk === 'Medium' ? 'text-amber-400' : 'text-rose-400'
                      }`}>
                        {st.delayRisk}
                      </span>
                    </div>
                  ))}
                </div>

              </div>
            )}

          </div>

        </div>

      </div>
    </section>
  );
};
