import React from 'react';
import { TECH_FEATURES } from '../data/trainData';
import { Brain, Code2, Zap, Layers, Database, TrendingUp, Cpu, Sparkles } from 'lucide-react';

const iconMap: Record<string, React.ReactNode> = {
  Brain: <Brain className="w-7 h-7 text-cyan-400" />,
  Code2: <Code2 className="w-7 h-7 text-blue-400" />,
  Zap: <Zap className="w-7 h-7 text-amber-400" />,
  Layers: <Layers className="w-7 h-7 text-emerald-400" />,
  Database: <Database className="w-7 h-7 text-purple-400" />,
  TrendingUp: <TrendingUp className="w-7 h-7 text-rose-400" />,
  Cpu: <Cpu className="w-7 h-7 text-cyan-300" />
};

export const TechStack: React.FC = () => {
  return (
    <section id="tech" className="py-24 relative overflow-hidden bg-slate-950 cyber-grid">
      
      {/* Background ambient lighting */}
      <div className="absolute top-1/3 left-1/3 w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-mono-tech">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            AI & CLOUD SYSTEM ARCHITECTURE
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-slate-100">
            Powered by <span className="text-gradient">Next-Gen AI Tech</span>
          </h2>
          <p className="text-slate-400 text-base sm:text-lg">
            High-performance technology stack processing millions of IRCTC telemetry data points in real-time.
          </p>
        </div>

        {/* 7 Floating Tech Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {TECH_FEATURES.map((tech, i) => (
            <div
              key={i}
              className="glass-card-interactive p-6 border border-cyan-500/20 hover:border-cyan-400/50 transition-all duration-300 group hover:-translate-y-2 relative overflow-hidden"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 group-hover:scale-110 transition-transform">
                  {iconMap[tech.icon] || <Cpu className="w-7 h-7 text-cyan-400" />}
                </div>
                <span className="px-2.5 py-1 rounded-full text-[10px] font-mono-tech font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
                  {tech.tag}
                </span>
              </div>

              <h3 className="text-xl font-bold text-slate-100 mb-1">{tech.name}</h3>
              <p className="text-xs font-mono-tech text-cyan-300/80 mb-3">{tech.tech}</p>
              
              <p className="text-xs text-slate-400 leading-relaxed">{tech.desc}</p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
