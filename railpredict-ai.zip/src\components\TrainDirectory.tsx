import React, { useState } from 'react';
import { INDIAN_TRAINS, type TrainInfo } from '../data/trainData';
import { Database, Eye, X } from 'lucide-react';

export const TrainDirectory: React.FC = () => {
  const [filterType, setFilterType] = useState<string>('All');
  const [selectedTrain, setSelectedTrain] = useState<TrainInfo | null>(null);

  const filteredTrains = filterType === 'All' 
    ? INDIAN_TRAINS 
    : INDIAN_TRAINS.filter(t => t.type === filterType);

  return (
    <section id="directory" className="py-24 relative overflow-hidden bg-slate-950/90">
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-400 text-xs font-mono-tech mb-3">
              <Database className="w-4 h-4 text-purple-400" />
              INDIAN RAILWAYS TRAIN DATABASE & GALLERY
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold text-slate-100">
              Train Specifications & <span className="text-gradient-purple">Image Gallery</span>
            </h2>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap gap-2">
            {['All', 'Vande Bharat', 'Rajdhani', 'Shatabdi', 'Superfast'].map((type) => (
              <button
                key={type}
                onClick={() => setFilterType(type)}
                className={`px-4 py-2 rounded-xl text-xs font-bold font-mono-tech transition-all ${
                  filterType === type
                    ? 'bg-purple-600 text-slate-100 shadow-lg shadow-purple-600/40'
                    : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {/* Train Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredTrains.map((train) => (
            <div
              key={train.id}
              className="glass-card-interactive border border-slate-800 hover:border-purple-500/40 overflow-hidden group flex flex-col justify-between"
            >
              {/* Train Image Gallery Item */}
              <div className="relative h-52 overflow-hidden bg-slate-900">
                <img
                  src={train.image}
                  alt={train.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-90"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />
                
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 rounded-full text-xs font-bold font-mono-tech bg-purple-500/80 text-white shadow-lg backdrop-blur-md">
                    {train.type}
                  </span>
                </div>

                <div className="absolute bottom-3 left-4 right-4">
                  <span className="text-xs font-mono-tech text-cyan-400 font-bold tracking-widest uppercase">
                    TRAIN NO. {train.number}
                  </span>
                  <h3 className="text-lg font-extrabold text-slate-100 line-clamp-1">
                    {train.name}
                  </h3>
                </div>
              </div>

              {/* Specs Summary */}
              <div className="p-6 space-y-4 flex-1 flex flex-col justify-between">
                <div className="space-y-3">
                  <div className="flex justify-between items-center text-xs text-slate-300 font-medium">
                    <span className="text-slate-400">Route Corridor:</span>
                    <span className="font-bold text-slate-100">{train.sourceCode} ➔ {train.destCode}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs font-mono-tech bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                    <div>
                      <span className="text-slate-500 text-[10px] block">AVG SPEED</span>
                      <span className="text-cyan-400 font-bold">{train.avgSpeedKmh} KM/H</span>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[10px] block">DISTANCE</span>
                      <span className="text-purple-400 font-bold">{train.distanceKm} KM</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setSelectedTrain(train)}
                  className="w-full py-3 rounded-xl bg-slate-900 hover:bg-purple-600/30 text-slate-200 hover:text-purple-300 border border-slate-800 hover:border-purple-500/50 text-xs font-bold font-mono-tech flex items-center justify-center gap-2 transition-all mt-4"
                >
                  <Eye className="w-4 h-4" />
                  View Full Train Specs
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Modal Detail View */}
      {selectedTrain && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
          <div className="glass-card-interactive max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 border border-purple-500/40 relative space-y-6">
            
            <button
              onClick={() => setSelectedTrain(null)}
              className="absolute top-6 right-6 p-2 rounded-full bg-slate-900 text-slate-400 hover:text-slate-100 border border-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <span className="px-3 py-1 rounded-full text-xs font-bold font-mono-tech bg-purple-500 text-white">
                {selectedTrain.type}
              </span>
              <span className="text-xs font-mono-tech text-cyan-400">NUMBER: {selectedTrain.number}</span>
            </div>

            <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-100">{selectedTrain.name}</h3>

            <p className="text-sm text-slate-300 leading-relaxed">{selectedTrain.description}</p>

            {/* Quick Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 font-mono-tech block">DISTANCE</span>
                <span className="text-sm font-bold text-slate-100 font-mono-tech">{selectedTrain.distanceKm} KM</span>
              </div>
              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 font-mono-tech block">MAX SPEED</span>
                <span className="text-sm font-bold text-cyan-400 font-mono-tech">{selectedTrain.maxSpeedKmh} KM/H</span>
              </div>
              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 font-mono-tech block">PUNCTUALITY</span>
                <span className="text-sm font-bold text-emerald-400 font-mono-tech">{selectedTrain.reliabilityScore}%</span>
              </div>
              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 font-mono-tech block">HISTORIC DELAY</span>
                <span className="text-sm font-bold text-amber-400 font-mono-tech">{selectedTrain.avgDelayMins} MINS</span>
              </div>
            </div>

            {/* Coach Composition */}
            <div>
              <h4 className="text-xs font-mono-tech text-slate-400 uppercase tracking-wider mb-2">COACH COMPOSITION</h4>
              <div className="flex flex-wrap gap-2">
                {selectedTrain.coaches.map((c, idx) => (
                  <span key={idx} className="px-3 py-1.5 rounded-lg bg-slate-900 text-xs font-mono-tech text-slate-300 border border-slate-800">
                    {c.type}: <strong className="text-cyan-400">{c.count} Coaches</strong>
                  </span>
                ))}
              </div>
            </div>

            {/* Route Stations Timetable */}
            <div>
              <h4 className="text-xs font-mono-tech text-slate-400 uppercase tracking-wider mb-3">SCHEDULED STOPS & DELAY RISK</h4>
              <div className="space-y-2">
                {selectedTrain.routeStations.map((st, idx) => (
                  <div key={idx} className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex justify-between items-center text-xs">
                    <div>
                      <span className="font-bold text-slate-200">{st.name} ({st.code})</span>
                      <span className="text-[11px] text-slate-500 block">Day {st.day}</span>
                    </div>
                    <div className="text-right">
                      <span className="font-mono-tech text-slate-300">{st.time}</span>
                      <span className={`block text-[10px] font-bold ${
                        st.delayRisk === 'Low' ? 'text-emerald-400' : st.delayRisk === 'Medium' ? 'text-amber-400' : 'text-rose-400'
                      }`}>
                        {st.delayRisk} Delay Risk
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      )}

    </section>
  );
};
