import React, { useState } from 'react';
import { MAJOR_STATIONS } from '../data/trainData';
import { MapPin, Train, Radio } from 'lucide-react';

export const IndiaMap: React.FC = () => {
  const [selectedStation, setSelectedStation] = useState<typeof MAJOR_STATIONS[0] | null>(MAJOR_STATIONS[0]);
  const [activeOverlay, setActiveOverlay] = useState<'routes' | 'delays' | 'weather'>('routes');

  const getMapCoords = (lat: number, lng: number) => {
    const x = ((lng - 68) / (96 - 68)) * 80 + 10;
    const y = (1 - (lat - 8) / (35 - 8)) * 80 + 10;
    return { x, y };
  };

  return (
    <section id="map" className="py-24 relative overflow-hidden bg-slate-950 cyber-grid">
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono-tech">
            <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
            3D SPATIAL NETWORK VISUALIZER
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-slate-100">
            Interactive <span className="text-gradient">India Railway Map</span>
          </h2>
          <p className="text-slate-400 text-base sm:text-lg">
            Real-time pan-Indian railway grid displaying active train positions, corridor delay hotspots, and meteorological weather overlays.
          </p>
        </div>

        {/* Map Container & Interactive Controls */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Map Graphic Box (Left 8 Cols) */}
          <div className="lg:col-span-8 glass-card-interactive p-6 border border-cyan-500/30 relative min-h-[520px] flex items-center justify-center overflow-hidden">
            
            {/* Overlay Selector Controls */}
            <div className="absolute top-4 left-4 z-20 flex gap-2">
              <button
                onClick={() => setActiveOverlay('routes')}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono-tech ${
                  activeOverlay === 'routes' ? 'bg-cyan-500 text-slate-950 font-bold' : 'bg-slate-900 text-slate-300 border border-slate-800'
                }`}
              >
                Trunk Routes
              </button>
              <button
                onClick={() => setActiveOverlay('delays')}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono-tech ${
                  activeOverlay === 'delays' ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-900 text-slate-300 border border-slate-800'
                }`}
              >
                Delay Hotspots
              </button>
              <button
                onClick={() => setActiveOverlay('weather')}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono-tech ${
                  activeOverlay === 'weather' ? 'bg-blue-500 text-slate-950 font-bold' : 'bg-slate-900 text-slate-300 border border-slate-800'
                }`}
              >
                Weather Zones
              </button>
            </div>

            {/* Glowing Map SVG */}
            <div className="relative w-full h-[450px] max-w-xl mx-auto">
              
              <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                
                <defs>
                  <linearGradient id="routeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#00f2fe" stopOpacity="0.8" />
                    <stop offset="50%" stopColor="#4facfe" stopOpacity="0.5" />
                    <stop offset="100%" stopColor="#7f00ff" stopOpacity="0.8" />
                  </linearGradient>
                  
                  <filter id="neonGlow" x="-20%" y="-20%" width="140%" height="140%">
                    <feGaussianBlur stdDeviation="1.5" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                </defs>

                {/* Connecting Railway Lines */}
                <line x1="43" y1="28" x2="27" y2="57" stroke="url(#routeGradient)" strokeWidth="0.8" filter="url(#neonGlow)" strokeDasharray="2 1" />
                <line x1="43" y1="28" x2="82" y2="46" stroke="url(#routeGradient)" strokeWidth="0.8" filter="url(#neonGlow)" strokeDasharray="2 1" />
                <line x1="43" y1="28" x2="53" y2="74" stroke="url(#routeGradient)" strokeWidth="0.6" filter="url(#neonGlow)" />
                <line x1="27" y1="57" x2="44" y2="75" stroke="url(#routeGradient)" strokeWidth="0.8" filter="url(#neonGlow)" />
                <line x1="53" y1="74" x2="44" y2="75" stroke="url(#routeGradient)" strokeWidth="0.8" filter="url(#neonGlow)" />
                <line x1="82" y1="46" x2="53" y2="74" stroke="url(#routeGradient)" strokeWidth="0.8" filter="url(#neonGlow)" />
                <line x1="43" y1="28" x2="26" y2="44" stroke="url(#routeGradient)" strokeWidth="0.8" filter="url(#neonGlow)" />

                {activeOverlay === 'weather' && (
                  <>
                    <circle cx="50" cy="30" r="14" fill="#00f2fe" fillOpacity="0.15" className="animate-pulse" />
                    <text x="45" y="32" fill="#00f2fe" fontSize="2.5" fontFamily="JetBrains Mono">Dense Fog Zone</text>
                  </>
                )}

                {activeOverlay === 'delays' && (
                  <>
                    <circle cx="62" cy="38" r="8" fill="#f43f5e" fillOpacity="0.25" className="animate-ping" />
                    <text x="56" y="39" fill="#f43f5e" fontSize="2.5" fontFamily="JetBrains Mono">DDU Bottleneck (+45m)</text>
                  </>
                )}

                {MAJOR_STATIONS.map((station) => {
                  const { x, y } = getMapCoords(station.lat, station.lng);
                  const isSelected = selectedStation?.code === station.code;

                  return (
                    <g key={station.code} onClick={() => setSelectedStation(station)} className="cursor-pointer group">
                      <circle
                        cx={x}
                        cy={y}
                        r={isSelected ? "2.5" : "1.5"}
                        className={`${isSelected ? 'fill-cyan-400 stroke-cyan-200' : 'fill-slate-100 stroke-cyan-500'} transition-all`}
                        strokeWidth="0.5"
                      />
                      <circle
                        cx={x}
                        cy={y}
                        r={isSelected ? "4" : "2.5"}
                        className="fill-none stroke-cyan-400 opacity-60 animate-ping"
                        strokeWidth="0.2"
                      />
                      <text
                        x={x + 2}
                        y={y + 1}
                        fill="#f3f4f6"
                        fontSize="2.2"
                        fontWeight="bold"
                        fontFamily="Outfit"
                        className="group-hover:fill-cyan-300 transition-colors"
                      >
                        {station.name}
                      </text>
                    </g>
                  );
                })}
              </svg>

              <div className="absolute top-[35%] left-[38%] pointer-events-none flex items-center gap-1 bg-cyan-500/20 px-2 py-0.5 rounded-full border border-cyan-400/40 backdrop-blur-md animate-bounce">
                <Train className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-[9px] font-mono-tech text-cyan-300 font-bold">12951 IN-TRANSIT</span>
              </div>
            </div>

          </div>

          {/* Selected Station Telemetry Card (Right 4 Cols) */}
          <div className="lg:col-span-4 glass-card-interactive p-6 border border-cyan-500/30 space-y-6">
            
            <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
              <div className="p-3 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                <MapPin className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xs font-mono-tech text-slate-400">STATION HUB PROFILE</span>
                <h3 className="text-xl font-bold text-slate-100">{selectedStation?.name}</h3>
                <p className="text-xs text-cyan-400 font-mono-tech">CODE: {selectedStation?.code} • {selectedStation?.state}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 text-center">
                <p className="text-[10px] text-slate-400 font-mono-tech">DAILY TRAIN FLOW</p>
                <p className="text-xl font-bold text-slate-100 font-mono-tech mt-1">420+ Trains</p>
              </div>
              <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 text-center">
                <p className="text-[10px] text-slate-400 font-mono-tech">PUNCTUALITY INDEX</p>
                <p className="text-xl font-bold text-emerald-400 font-mono-tech mt-1">94.2%</p>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="text-xs font-mono-tech text-slate-400 uppercase">ACTIVE TRAINS NEAR NODE</h4>
              
              <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-slate-200">12951 Mumbai Rajdhani</span>
                  <span className="text-emerald-400 font-mono-tech text-[11px]">ON TIME</span>
                </div>
                <p className="text-[11px] text-slate-400">Platform 1 • Departs 17:00</p>
              </div>

              <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-slate-200">20901 Vande Bharat</span>
                  <span className="text-cyan-400 font-mono-tech text-[11px]">+4 Mins</span>
                </div>
                <p className="text-[11px] text-slate-400">Platform 5 • Approaching outer signal</p>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-xs font-mono-tech text-cyan-300 text-center">
              💡 Click any station marker on the map to switch live node telemetry.
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
