import React, { useState, useEffect } from 'react';
import { Train, Activity, Cpu, MapPin, Database, HelpCircle, Menu, X, Sparkles } from 'lucide-react';

interface NavbarProps {
  onOpenChat: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenChat }) => {
  const [timeStr, setTimeStr] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString('en-US', { hour12: false }) + ' IST');
    };
    updateClock();
    const interval = setInterval(updateClock, 1000);

    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);

    return () => {
      clearInterval(interval);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      scrolled 
        ? 'bg-slate-950/85 backdrop-blur-xl border-b border-cyan-500/20 py-3 shadow-2xl shadow-cyan-950/20' 
        : 'bg-transparent py-5'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          
          {/* Brand Logo */}
          <a href="#" className="flex items-center gap-3 group">
            <div className="relative w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 p-0.5 flex items-center justify-center shadow-lg shadow-cyan-500/30 group-hover:scale-105 transition-transform">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Train className="w-5 h-5 text-cyan-400 group-hover:rotate-12 transition-transform" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl font-extrabold tracking-wider text-slate-100 font-mono-tech">RAILPREDICT</span>
                <span className="px-1.5 py-0.5 text-[10px] font-bold rounded bg-cyan-500/20 text-cyan-400 border border-cyan-500/40">AI</span>
              </div>
              <p className="text-[10px] text-slate-400 font-mono-tech tracking-widest uppercase">INDIAN RAILWAYS COMMAND</p>
            </div>
          </a>

          {/* Center Navigation Links (Desktop) */}
          <div className="hidden lg:flex items-center gap-8 text-sm font-medium">
            <a href="#predictor" className="text-slate-300 hover:text-cyan-400 transition-colors flex items-center gap-1.5">
              <Cpu className="w-4 h-4 text-cyan-400" />
              Predict Delay
            </a>
            <a href="#dashboard" className="text-slate-300 hover:text-cyan-400 transition-colors flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-blue-400" />
              Dashboard
            </a>
            <a href="#map" className="text-slate-300 hover:text-cyan-400 transition-colors flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-emerald-400" />
              Railway Map
            </a>
            <a href="#directory" className="text-slate-300 hover:text-cyan-400 transition-colors flex items-center gap-1.5">
              <Database className="w-4 h-4 text-purple-400" />
              Train Directory
            </a>
            <a href="#tech" className="text-slate-300 hover:text-cyan-400 transition-colors flex items-center gap-1.5">
              <HelpCircle className="w-4 h-4 text-amber-400" />
              Tech Stack
            </a>
          </div>

          {/* Right Status & AI Action Button */}
          <div className="hidden md:flex items-center gap-4">
            <div className="text-right font-mono-tech">
              <div className="text-xs text-cyan-400 flex items-center gap-1.5 justify-end">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                {timeStr}
              </div>
              <span className="text-[10px] text-slate-400 uppercase">SYS TELEMETRY ACTIVE</span>
            </div>

            <button
              onClick={onOpenChat}
              className="btn-neon-primary py-2 px-4 text-xs font-semibold rounded-xl flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-slate-950 animate-spin" style={{ animationDuration: '8s' }} />
              RailMind Assistant
            </button>
          </div>

          {/* Mobile menu button */}
          <div className="lg:hidden flex items-center gap-2">
            <button
              onClick={onOpenChat}
              className="p-2 rounded-lg bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
            >
              <Sparkles className="w-5 h-5" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-slate-900 text-slate-300 border border-slate-800"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-slate-950/95 backdrop-blur-2xl border-b border-cyan-500/30 px-4 pt-4 pb-6 mt-3 space-y-3">
          <a
            href="#predictor"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 text-slate-200 hover:text-cyan-400 font-medium border-b border-slate-800"
          >
            Predict Train Delay
          </a>
          <a
            href="#dashboard"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 text-slate-200 hover:text-cyan-400 font-medium border-b border-slate-800"
          >
            SaaS Dashboard
          </a>
          <a
            href="#map"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 text-slate-200 hover:text-cyan-400 font-medium border-b border-slate-800"
          >
            India Railway Map
          </a>
          <a
            href="#directory"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 text-slate-200 hover:text-cyan-400 font-medium border-b border-slate-800"
          >
            Train Directory & Gallery
          </a>
          <a
            href="#tech"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 text-slate-200 hover:text-cyan-400 font-medium"
          >
            Technology & ML Architecture
          </a>
        </div>
      )}
    </nav>
  );
};
