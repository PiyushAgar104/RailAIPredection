import React from 'react';
import { Train, Shield } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-950 border-t border-cyan-500/20 py-16 text-slate-400 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 pb-12 border-b border-slate-800">
          
          {/* Col 1: Brand Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center">
                <Train className="w-5 h-5 text-cyan-400" />
              </div>
              <span className="text-lg font-bold text-slate-100 font-mono-tech">RAILPREDICT AI</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Pan-Indian Railway Delay Forecasting System powered by XGBoost machine learning algorithms and live GPS signal telemetry.
            </p>
            <div className="flex items-center gap-2 text-xs font-mono-tech text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              SYS STATUS: 100% OPERATIONAL
            </div>
          </div>

          {/* Col 2: Navigation */}
          <div className="space-y-3 font-mono-tech text-xs">
            <h4 className="text-sm font-bold text-slate-200 uppercase tracking-wider font-sans">Core Modules</h4>
            <ul className="space-y-2">
              <li><a href="#predictor" className="hover:text-cyan-400 transition-colors">Predict Train Delay</a></li>
              <li><a href="#dashboard" className="hover:text-cyan-400 transition-colors">SaaS Analytics Dashboard</a></li>
              <li><a href="#map" className="hover:text-cyan-400 transition-colors">3D Spatial India Map</a></li>
              <li><a href="#directory" className="hover:text-cyan-400 transition-colors">Train Spec Directory</a></li>
            </ul>
          </div>

          {/* Col 3: Tech & AI Models */}
          <div className="space-y-3 font-mono-tech text-xs">
            <h4 className="text-sm font-bold text-slate-200 uppercase tracking-wider font-sans">AI & ML Models</h4>
            <ul className="space-y-2">
              <li className="text-slate-400">XGBoost Gradient Classifier v4.2</li>
              <li className="text-slate-400">LSTM Sequential Delay Model</li>
              <li className="text-slate-400">FastAPI Asynchronous Pipeline</li>
              <li className="text-slate-400">IRCTC Open Telemetry API</li>
            </ul>
          </div>

          {/* Col 4: Legal & Security */}
          <div className="space-y-3 font-mono-tech text-xs">
            <h4 className="text-sm font-bold text-slate-200 uppercase tracking-wider font-sans">Security & Compliance</h4>
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
              <div className="flex items-center gap-2 text-cyan-400 font-bold">
                <Shield className="w-4 h-4" /> ISO-27001 Certified
              </div>
              <p className="text-[11px] text-slate-500">256-bit SSL encrypted telemetry streams across all rail zones.</p>
            </div>
          </div>

        </div>

        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs font-mono-tech text-slate-500 gap-4">
          <p>© 2026 RailPredict AI Systems. Engineered for Indian Railways.</p>
          <p>Built with React 18, Vite, Three.js & Tailwind CSS.</p>
        </div>

      </div>
    </footer>
  );
};
