import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Predictor } from './components/Predictor';
import { Dashboard } from './components/Dashboard';
import { IndiaMap } from './components/IndiaMap';
import { TrainDirectory } from './components/TrainDirectory';
import { TechStack } from './components/TechStack';
import { AIChatbot } from './components/AIChatbot';
import { Footer } from './components/Footer';
import { Sparkles } from 'lucide-react';

export const App: React.FC = () => {
  const [isChatOpen, setIsChatOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 selection:bg-cyan-500 selection:text-slate-950">
      
      {/* Top Navbar */}
      <Navbar onOpenChat={() => setIsChatOpen(true)} />

      {/* Main Sections */}
      <main>
        <Hero />
        <Predictor />
        <Dashboard />
        <IndiaMap />
        <TrainDirectory />
        <TechStack />
      </main>

      {/* Floating AI Chatbot Toggle Button (if closed) */}
      {!isChatOpen && (
        <button
          onClick={() => setIsChatOpen(true)}
          className="fixed bottom-6 right-6 z-40 btn-neon-primary p-4 rounded-full shadow-2xl flex items-center gap-3 border border-cyan-300 group hover:scale-110 transition-all"
        >
          <Sparkles className="w-6 h-6 text-slate-950 animate-spin" style={{ animationDuration: '6s' }} />
          <span className="text-xs font-bold font-mono-tech hidden sm:inline">Ask RailMind AI</span>
        </button>
      )}

      {/* RailMind AI Assistant Chatbot Modal */}
      <AIChatbot isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} />

      {/* Footer */}
      <Footer />
    </div>
  );
};

export default App;
