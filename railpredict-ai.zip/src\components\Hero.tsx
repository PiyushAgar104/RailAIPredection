import React, { useState } from 'react';
import { Train3DCanvas } from './Train3DCanvas';
import { ArrowRight, Zap, Radio, LineChart, Image as ImageIcon, Box } from 'lucide-react';

export const Hero: React.FC = () => {
  const [viewMode, setViewMode] = useState<'3d' | 'image'>('image');

  return (
    <section className="relative pt-28 pb-20 overflow-hidden cyber-grid">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-cyan-500/10 rounded-full blur-[140px] pointer-events-none animate-pulse-glow" />
      <div className="absolute top-1/3 left-1/4 w-[400px] h-[400px] bg-purple-600/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Top Tagline Badge */}
        <div className="flex justify-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-panel border border-cyan-500/30 text-cyan-300 text-xs font-mono-tech shadow-lg shadow-cyan-950/40">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
            </span>
            <span className="tracking-wider uppercase">AI TELEMETRY ENGINE v4.2 • PAN-INDIA NETWORK</span>
            <span className="text-slate-500">|</span>
            <span className="text-slate-300 flex items-center gap-1">
              <Radio className="w-3.5 h-3.5 text-emerald-400" />
              13,000+ TRAINS MONITORED
            </span>
          </div>
        </div>

        {/* Main Hero Header */}
        <div className="text-center max-w-4xl mx-auto space-y-6">
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-slate-100 leading-tight">
            AI Powered <br className="hidden sm:block" />
            <span className="text-gradient">Train Delay Prediction</span> System
          </h1>

          <p className="text-lg sm:text-xl text-slate-300 max-w-3xl mx-auto font-normal leading-relaxed">
            Predict Indian Railway delays using Machine Learning, historical data and intelligent forecasting. Harnessing XGBoost, LSTM neural nets, and live station congestion telemetry.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
            <a
              href="#predictor"
              className="btn-neon-primary text-base font-bold px-8 py-4 rounded-xl flex items-center gap-3 shadow-xl"
            >
              <Zap className="w-5 h-5 fill-current" />
              Predict Train Delay
              <ArrowRight className="w-5 h-5" />
            </a>

            <a
              href="#map"
              className="btn-neon-outline text-base font-bold px-8 py-4 rounded-xl flex items-center gap-3"
            >
              <LineChart className="w-5 h-5 text-cyan-400" />
              Explore Railway Network
            </a>
          </div>

          {/* Quick Metrics Bar */}
          <div className="pt-8 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
            <div className="glass-panel p-4 text-center border border-cyan-500/20">
              <p className="text-xs text-slate-400 uppercase font-mono-tech">PREDICTION ACCURACY</p>
              <p className="text-2xl font-bold text-glow-cyan font-mono-tech mt-1">92.4%</p>
            </div>
            <div className="glass-panel p-4 text-center border border-cyan-500/20">
              <p className="text-xs text-slate-400 uppercase font-mono-tech">ACTIVE STATIONS</p>
              <p className="text-2xl font-bold text-slate-100 font-mono-tech mt-1">7,325+</p>
            </div>
            <div className="glass-panel p-4 text-center border border-cyan-500/20">
              <p className="text-xs text-slate-400 uppercase font-mono-tech">DAILY INFERENCES</p>
              <p className="text-2xl font-bold text-purple-400 font-mono-tech mt-1">2.5M+</p>
            </div>
            <div className="glass-panel p-4 text-center border border-cyan-500/20">
              <p className="text-xs text-slate-400 uppercase font-mono-tech">AVG LATENCY</p>
              <p className="text-2xl font-bold text-emerald-400 font-mono-tech mt-1">&lt; 15 ms</p>
            </div>
          </div>
        </div>

        {/* Train Visual Showcase Mode Switcher */}
        <div className="mt-14 relative">
          
          <div className="flex justify-center mb-4 z-20 relative">
            <div className="inline-flex p-1.5 rounded-xl bg-slate-900/90 border border-cyan-500/30 backdrop-blur-md gap-2">
              <button
                onClick={() => setViewMode('image')}
                className={`px-4 py-2 rounded-lg text-xs font-bold font-mono-tech flex items-center gap-2 transition-all ${
                  viewMode === 'image'
                    ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <ImageIcon className="w-4 h-4" />
                Futuristic Train Photo
              </button>

              <button
                onClick={() => setViewMode('3d')}
                className={`px-4 py-2 rounded-lg text-xs font-bold font-mono-tech flex items-center gap-2 transition-all ${
                  viewMode === '3d'
                    ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Box className="w-4 h-4" />
                3D WebGL Simulation
              </button>
            </div>
          </div>

          {/* Render Mode 1: High Resolution Futuristic Train Image Card */}
          {viewMode === 'image' && (
            <div className="relative w-full h-[550px] md:h-[680px] rounded-2xl overflow-hidden glass-panel border border-cyan-500/40 group">
              <img
                src="/futuristic_indian_train.jpg"
                alt="Futuristic Indian Electric Locomotive"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000 brightness-105 contrast-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />

              {/* Holographic Overlay Labels */}
              <div className="absolute top-6 left-6 flex flex-wrap gap-3 pointer-events-none">
                <div className="glass-panel px-4 py-2 flex items-center gap-2 border border-cyan-400/40 bg-slate-950/80 backdrop-blur-md">
                  <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
                  <span className="text-xs font-mono-tech tracking-wider text-cyan-300">VANDE BHARAT CYBER-EXPRESS</span>
                </div>
                <div className="glass-panel px-4 py-2 flex items-center gap-2 border border-emerald-400/40 bg-slate-950/80 backdrop-blur-md">
                  <span className="text-xs font-mono-tech text-emerald-400">MAX SPEED: 160 KM/H</span>
                </div>
              </div>

              <div className="absolute bottom-6 left-6 right-6 pointer-events-none flex justify-between items-end">
                <div className="glass-panel p-4 border border-cyan-500/30 bg-slate-950/80 backdrop-blur-md max-w-md">
                  <h4 className="text-sm font-bold text-slate-100 font-mono-tech mb-1">NEXT-GEN ELECTRIC LOCOMOTIVE</h4>
                  <p className="text-xs text-slate-300">Aerodynamic alloy body, regenerative electric braking, smart IoT signal sensors, and 0-100 km/h acceleration in 52 seconds.</p>
                </div>
              </div>
            </div>
          )}

          {/* Render Mode 2: 3D Three.js Locomotive Canvas */}
          {viewMode === '3d' && (
            <Train3DCanvas />
          )}

        </div>

      </div>
    </section>
  );
};
